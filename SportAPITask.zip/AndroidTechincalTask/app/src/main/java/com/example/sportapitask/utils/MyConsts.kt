package com.example.sportapitask.utils

class MyConsts {
    companion object{
        val APIARY_BASE_URL = "https://private-anon-21a8016ef8-technicaltaskapi.apiary-mock.com"
    }
}