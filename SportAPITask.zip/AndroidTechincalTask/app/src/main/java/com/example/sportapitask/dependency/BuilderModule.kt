package com.example.sportapitask.dependency

import dagger.Module

@Module
abstract class BuilderModule {
}