package com.example.sportapitask.data.models


import com.google.gson.annotations.SerializedName

data class Author(
    var id: Int,
    var name: String
)